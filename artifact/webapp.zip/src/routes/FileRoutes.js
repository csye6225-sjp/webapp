// src/routes/fileRoutes.js
const express = require("express");
const multer = require("multer");
const { uploadFile, getFile, deleteFile } = require("../controllers/FileController");

// Multer setup: store file in memory as a buffer
const upload = multer({ storage: multer.memoryStorage() });

const router = express.Router();

// POST /v1/file
router.post("/", upload.single("profilePic"), uploadFile);

// GET /v1/file/:id
router.get("/:id", getFile);

// DELETE /v1/file/:id
router.delete("/:id", deleteFile);

module.exports = router;
