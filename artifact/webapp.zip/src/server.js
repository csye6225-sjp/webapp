// src/server.js
require("dotenv").config();
const express = require("express");
const sequelize = require("./config/db");
const fileRoutes = require("./routes/FileRoutes");

const app = express();

// For other JSON endpoints (like health check), use express.json()
app.use(express.json());

// File routes: note your swagger path says "/v1/file"
app.use("/v1/file", fileRoutes);

// Example health check
app.use("/healthz", (req, res) => res.sendStatus(200));

// Sync DB & start server if not in test
if (process.env.NODE_ENV !== "test") {
  (async () => {
    try {
      await sequelize.sync();
      console.log("DB synced!");
      const PORT = process.env.PORT || 8080;
      app.listen(PORT, "0.0.0.0", () => {
        console.log(`Server running on port ${PORT}`);
      });
    } catch (err) {
      console.error("DB sync error:", err);
      process.exit(1);
    }
  })();
}

module.exports = app;
