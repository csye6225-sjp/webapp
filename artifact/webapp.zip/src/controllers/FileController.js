// src/controllers/fileController.js
const { v4: uuidv4 } = require("uuid");
const s3 = require("../config/s3");
const FileMetadata = require("../models/FileMetadata");

async function uploadFile(req, res) {
  try {
    // If no file was provided
    if (!req.file) {
      return res
        .status(400)
        .json({ error: "No file in request (profilePic)." });
    }

    // Extract original filename
    const originalName = req.file.originalname;

    // Suppose we generate a unique folderId:
    const folderId = uuidv4(); // a unique identifier

    // Then the object key is "folderId/filename"
    const key = `${folderId}/${originalName}`;

    await s3
      .upload({
        Bucket: process.env.S3_BUCKET,
        Key: key,
        Body: req.file.buffer,
        ContentType: "application/octet-stream",
      })
      .promise();

    // Construct the "url" (your Swagger example uses something like
    // "bucket-name/id/image-file.extension".
    const url = `${process.env.S3_BUCKET}/${key}`;

    // Insert into DB
    const record = await FileMetadata.create({
      id: folderId,
      fileName: originalName,
      fileKey: key,
      url,
    });

    // The Swagger says return 201 with:
    // {
    //   "file_name": "image.jpg",
    //   "id": "uuid",
    //   "url": "bucket-name/...",
    //   "upload_date": "2020-01-12"
    // }
    return res.status(201).json({
      id: record.id,
      file_name: record.fileName,
      url: record.url,
      // Since we rely on timestamps, we can map createdAt to "upload_date":
      upload_date: record.createdAt, // Or format it if needed
    });
  } catch (err) {
    console.error("Error uploading file:", err);
    return res.status(500).json({ error: "Internal Server Error" });
  }
}

// GET /v1/file/{id}
async function getFile(req, res) {
  try {
    const { id } = req.params;
    const record = await FileMetadata.findByPk(id);
    if (!record) {
      return res.status(404).json({ error: "File not found" });
    }

    if (!record) {
        return res.status(404).json({ error: "File not found" });
      }
    return res.status(200).json({
      file_name: record.fileName,
      id: record.id,
      url: record.url,
      upload_date: record.createdAt,
    });
  } catch (err) {
    console.error("Error fetching file:", err);
    return res.status(404).json({ error: "File not found" });
  }
}

// DELETE /v1/file/{id}
async function deleteFile(req, res) {
  try {
    const { id } = req.params;
    const record = await FileMetadata.findByPk(id);
    if (!record) {
      return res.sendStatus(404); // "Not Found"
    }

    // Delete from S3
    await s3
      .deleteObject({
        Bucket: process.env.S3_BUCKET,
        Key: record.fileKey,
      })
      .promise();

    // Delete from DB
    await record.destroy();

    // 204 "No Content" as per your Swagger
    return res.sendStatus(204);
  } catch (err) {
    console.error("Error fetching file:", err);
    return res.status(404).json({ error: "File not found" });
  }
}

module.exports = {
  uploadFile,
  getFile,
  deleteFile,
};
